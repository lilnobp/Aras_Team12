package com.parsa.plm.bri;
import java.util.*;

import com.parsa.plm.bri.ArasPartModel;
public class DataManagermentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<ArasPartModel> listData = new ArrayList<ArasPartModel>();
		
		RestApi.connection();
		RestApi.getAllItems();
        Collections.shuffle(listData, new Random());
        System.out.println("***************************************************");
       
       
		

	}

}
