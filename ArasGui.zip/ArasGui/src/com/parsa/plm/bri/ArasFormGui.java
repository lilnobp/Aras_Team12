package com.parsa.plm.bri;
import java.util.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import java.awt.Color;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import javax.swing.JSplitPane;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JList;
import java.awt.GridBagLayout;
import javax.swing.JDesktopPane;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.List;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.awt.event.ActionEvent;

public class ArasFormGui {

	private JFrame frmArasteamcenter;

	java.util.List<ArasPartModel> listData = new ArrayList<ArasPartModel>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
        
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArasFormGui window = new ArasFormGui();
					window.frmArasteamcenter.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ArasFormGui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmArasteamcenter = new JFrame();
		frmArasteamcenter.setTitle("Aras&TeamCenter");
		frmArasteamcenter.setBounds(100, 100, 450, 300);
		frmArasteamcenter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmArasteamcenter.getContentPane().setLayout(null);
		List ListTc = new List();
		ListTc.setBounds(237, 45, 156, 132);
		frmArasteamcenter.getContentPane().add(ListTc);
		List ListAras = new List();
		ListAras.setBounds(24, 45, 163, 132);
		frmArasteamcenter.getContentPane().add(ListAras);
		JButton btnGetAras = new JButton("get All Item Aras 12");
		btnGetAras.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				ListAras.clear();
				for (ArasPartModel var : listData) 
		        { 
					ListAras.add("ItemId: "+var.classification +" ,"+ "ItemName :");
					
		        }
				
			}
		});
		btnGetAras.setBounds(24, 11, 147, 23);
		frmArasteamcenter.getContentPane().add(btnGetAras);
		
		JButton btnGetTc = new JButton("get All Item Team11");
		btnGetTc.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				ListTc.clear();
				for (ArasPartModel var : listData) 
		        { 
					
					ListTc.add("ItemId: "+" ,"+ "ItemName :");
		        }
				
			}
		});
		btnGetTc.setBounds(237, 11, 156, 23);
		frmArasteamcenter.getContentPane().add(btnGetTc);
		
		
		
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(96, 225, 46, 22);
		frmArasteamcenter.getContentPane().add(textArea);
		
		JLabel lblItemId = new JLabel("New_ID :");
		lblItemId.setBounds(24, 225, 62, 22);
		frmArasteamcenter.getContentPane().add(lblItemId);
		
		JLabel lblNewLabel = new JLabel("New_ItemName");
		lblNewLabel.setBounds(152, 225, 95, 19);
		frmArasteamcenter.getContentPane().add(lblNewLabel);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(246, 225, 78, 23);
		frmArasteamcenter.getContentPane().add(textArea_1);
		
		JButton btnCreatItem = new JButton("Creat Item");
		btnCreatItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RestApi.connection();
				RestApi.creatItem(textArea_1.getText(),textArea.getText() );
				JOptionPane.showMessageDialog(frmArasteamcenter," Completely Sent To Aras.");
			}
		});
		btnCreatItem.setBounds(277, 191, 118, 23);
		frmArasteamcenter.getContentPane().add(btnCreatItem);
		
		JButton btnSendToAras = new JButton("To Aras");
		btnSendToAras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnSendToAras.setBounds(24, 191, 89, 23);
		frmArasteamcenter.getContentPane().add(btnSendToAras);
		
		JButton btnToTc11 = new JButton("To TC11");
		btnToTc11.setBounds(123, 191, 89, 23);
		frmArasteamcenter.getContentPane().add(btnToTc11);
	}
}
