package com.parsa.plm.bri;

public class ItemJsonTest {

	public static void main(String[] args) {
		RestApi.connection();
		RestApi.getAllItems();
     
	}

}
