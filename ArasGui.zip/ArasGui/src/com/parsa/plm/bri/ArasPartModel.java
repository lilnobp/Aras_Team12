package com.parsa.plm.bri;

import java.util.ArrayList;
import java.util.List;



public class ArasPartModel {
	
	public String classification;
	public String state;
	public String name;
	public String make_by;
	public String is_current;
	public String keyed_name;
	public String modified_on;
	public String new_version;
	public String unit;
	public String item_number;
	public String is_released;
	public String major_rev;
	public String not_lockable;
	public String release_date;
	public String has_change_pending;
	public String id;
	public String generation;
	public String description;
	public String current_state;
	public String itemtype;
	public String created_on;
	
	
	
}
