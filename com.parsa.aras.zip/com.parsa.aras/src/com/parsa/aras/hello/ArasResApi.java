package com.parsa.aras.hello;

public class ArasResApi {

}
