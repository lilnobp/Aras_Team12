package com.parsa.aras.hello;

public class ArasRestApi_Dummy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		ArasRestApi.connection();
		ArasRestApi.getAllItems();
		ArasRestApi.creatArasItem("HPLINL", "156789");
	}

}
