package com.parsa.aras.hello;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.Map;

import com.parsa.aras.clientx.*;

import com.parsa.aras.hello.*;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.strong.core._2006_03.DataManagement.CreateItemsOutput;
import com.teamcenter.services.strong.core._2006_03.DataManagement.ItemIdsAndInitialRevisionIds;
import com.teamcenter.services.strong.core._2006_03.DataManagement.RevisionIds;
import com.teamcenter.soa.client.model.strong.Item;
import com.teamcenter.soa.client.model.strong.ItemRevision;
import com.teamcenter.soa.client.model.strong.User;

public class HelloTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  System.out.println("usage: java [-Dhost=http://server:port/tc] com.teamcenter.hello.Hello");
	        if (args.length > 0)
	        {
	            if (args[0].equals("-help") || args[0].equals("-h"))
	            {
	                System.out.println("usage: java [-Dhost=http://server:port/tc] com.teamcenter.hello.Hello");
	                System.exit(0);
	            }
	        }

	        // Get optional host information
	        String serverHost = "http://localhost:7001/tc";
	        String host = System.getProperty("host");
	        if (host != null && host.length() > 0)
	        {
	            serverHost = host;
	        }



	        AppXSession   session = new AppXSession(serverHost);
	        HomeFolder   home = new HomeFolder();
	        Query       query = new Query();
	        DataManagement dm = new DataManagement();
	        

	        // Establish a session with the Teamcenter Server
	        User user = session.login();

	        // Using the User object returned from the login service request
	        // display the contents of the Home Folder
	        home.listHomeFolder(user);

	        // Perform a simple query of the database
	        query.queryItems();

	        // Perform some basic data management functions
	        dm.createReviseAndDelete();
	        
	        System.out.println("Now we wanna create an Item with the Initial parameters ");
	        InputStreamReader isr =new InputStreamReader(System.in);
	        String ItemsName =null;
	        BufferedReader br =new BufferedReader(isr);
	        System.out.println("Please give The Items Name:   ");
	        try {
				 ItemsName =br.readLine();
				 
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				ItemsName="not valid";
				e2.printStackTrace();
				
			}
	        int numberOfItems = 1;

            // Reserve Item IDs and Create Items with those IDs
            ItemIdsAndInitialRevisionIds[] itemIds = null;
			try {
				itemIds = dm.generateItemIds(numberOfItems, "Item");
				
			} catch (ServiceException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            try {
				CreateItemsOutput[] newItems = dm.createItems(itemIds, "Item",ItemsName);
				 Item[] items = new Item[newItems.length];
		            ItemRevision[] itemRevs = new ItemRevision[newItems.length];
		            for (int i = 0; i < items.length; i++)
		            {
		                items[i] = newItems[i].item;
		                itemRevs[i] = newItems[i].itemRev;
		            }

		            // Reserve revision IDs and revise the Items
		            Map<BigInteger,RevisionIds> allRevIds = dm.generateRevisionIds(items);
		            
		            dm.reviseItems(allRevIds, itemRevs);
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           
            System.out.println();
	        // Terminate the session with the Teamcenter server
	        session.logout();

	    }
	}


